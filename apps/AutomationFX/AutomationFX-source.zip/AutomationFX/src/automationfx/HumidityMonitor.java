package automationfx;

import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;
import javafx.beans.property.FloatProperty;
import javafx.beans.property.ReadOnlyFloatProperty;
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javax.ws.rs.client.WebTarget;

/**
 *
 * @author bruno.borges@oracle.com
 */
public class HumidityMonitor {

    private static final long DELAY = 15000; // 15s
    private FloatProperty floatValue = new SimpleFloatProperty();
    private StringProperty value = new SimpleStringProperty();
    private final WebTarget target;

    public HumidityMonitor(WebTarget target) {
        this.target = target.path("/humidity");
    }

    public void start() {
        Timer timer = new Timer(true);
        timer.schedule(new MonitorService(), 0, DELAY);
    }

    class MonitorService extends TimerTask {

        @Override
        public void run() {
            String sHumidity = target.request().get(String.class);
            final float humidity = new Float(sHumidity);
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    floatValue.set(humidity);
                    value.set(Float.toString(humidity));
                }
            });
        }
    }

    public ReadOnlyStringProperty valueProperty() {
        return value;
    }

    public ReadOnlyFloatProperty floatProperty() {
        return floatValue;
    }
}
