/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.eletronlivre.cofffeetimer;

import br.com.globalcode.eletronlivre.arduino.serial.Arduino;
import javax.ejb.EJB;
import javax.ejb.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.TimerService;

/**
 *
 * @author vsenger
 */
@Stateless

public class TurnOnBean implements WakeUpScheduler {
  @EJB
  private TurnOffBean turnOffBean;

  @Resource
  TimerService timerService;
  @Resource
  SessionContext ctx;
  @Override
  public void agendarTarefa(long emQuantoTempo, long porQuantoTempo) {
    System.out.println("Serviço agendado!");
    TimerService agendador = ctx.getTimerService();

    agendador.createTimer(emQuantoTempo,null);
    turnOffBean.agendarTarefa(porQuantoTempo + emQuantoTempo);

  }
  @Override
  public void agendarTarefa() {
    System.out.println("Serviço agendado!");
    TimerService agendador = ctx.getTimerService();
    agendador.createTimer(5000,5000,null);

  }

  @Timeout
  public void wakeUp(Timer timer) {
    System.out.println("Vamos ligarrr!");
    try {
      Arduino.enviar("A+B");
    } catch (Exception ex) {
      Logger.getLogger(TurnOnBean.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
}
