/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package clientconsole;

import br.com.eletronlivre.cofffeetimer.WakeUpScheduler;
import java.rmi.RemoteException;
import javax.ejb.EJB;

/**
 *
 * @author vsenger
 */
public class Main {
  @EJB
  private static WakeUpScheduler wakeUpBean;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws RemoteException {
        // TODO code application logic here
      wakeUpBean.agendarTarefa();
    }

}
